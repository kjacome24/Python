from flask import Flask, render_template, request, redirect
import datetime
app = Flask(__name__)  


@app.route('/')         
def index():
    return render_template("index.html")

@app.route('/checkout', methods=['POST','GET'])         
def checkout():
    if request.method=="POST":
        print(request.form)
        strawberry = request.form.get('strawberry')
        raspberry = request.form.get('raspberry')
        print(raspberry)
        apple = request.form.get('apple')
        first_name = request.form.get('first_name')
        last_name = request.form.get('last_name')
        student_id = request.form.get('student_id')
        total= int(apple)+int(raspberry)+int(strawberry)
        time_of_purchase = datetime.datetime.now()
        time_of_purchase = str(time_of_purchase)
        print(f"Cobrando a {first_name} {last_name} por {total} frutas")
        return render_template("checkout.html",strawberry=strawberry,raspberry=raspberry,apple=apple,first_name=first_name,last_name=last_name,student_id=student_id,total=total,time_of_purchase=time_of_purchase)
    else:
        return render_template("checkout.html")
    
@app.route('/fruits')         
def fruits():
    return render_template("fruits.html")

if __name__=="__main__":   
    app.run(debug=True)    